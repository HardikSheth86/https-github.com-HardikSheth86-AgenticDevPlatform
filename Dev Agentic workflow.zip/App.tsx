
import React, { useState, useCallback, useMemo } from 'react';
import { 
  AgentRole, 
  WorkflowStage, 
  UserStory, 
  DevTask, 
  CodeFile, 
  AgentLog, 
  CodeReviewComment,
  Repository,
  PullRequest
} from './types';
import { agentService } from './services/geminiService';
import { COMPLIANCE_FILES } from './data/complianceTemplates';
import AgentCard from './components/AgentCard';
import LogTerminal from './components/LogTerminal';
import WorkflowSteps from './components/WorkflowSteps';
import Tabs from './components/Tabs';
import Sidebar from './components/Sidebar';
import SettingsModal from './components/SettingsModal';
import AddRepoModal from './components/AddRepoModal';
import DashboardStats from './components/DashboardStats';
import CopilotChat from './components/CopilotChat';
import DetailModal from './components/DetailModal';
import { 
  Send, FileText, Code, Brain, GitPullRequest, Terminal, CheckCircle, 
  CheckCircle2, Sparkles, UserCheck, ExternalLink, ArrowRight, XCircle, 
  RotateCcw, MessageSquare, FolderPlus, Rocket, Command, ShieldAlert, 
  Github, Percent, AlertTriangle, FileJson, FileLock, BookOpen, ScrollText, 
  AlertOctagon, X, ThumbsDown, ThumbsUp, Wrench, ShieldCheck, RefreshCw, 
  GitBranch, GitMerge, FileCode, CheckCircle as CheckIcon, AlertCircle, 
  User, Bot, ChevronRight, Layout, Search, Layers, Briefcase, PlayCircle,
  Clock, Activity, Gauge
} from 'lucide-react';

// Mock Data
const INITIAL_REPOS: Repository[] = [
  { id: '5', name: 'Sapphire', description: 'Enterprise AI Agent (Copilot Workspace)', language: 'Python', stars: 12, openPrs: 2, branch: 'main', source: 'google-studio', complianceStatus: 'compliant' },
  { id: '1', name: 'e-commerce-platform', description: 'Next.js storefront with Stripe integration', language: 'TypeScript', stars: 124, openPrs: 3, branch: 'main', source: 'github', complianceStatus: 'pending' },
  { id: '2', name: 'data-pipeline-worker', description: 'Python ETL service for analytics', language: 'Python', stars: 45, openPrs: 0, branch: 'develop', source: 'github', complianceStatus: 'missing' },
  { id: '3', name: 'auth-service', description: 'Go microservice for authentication', language: 'Go', stars: 89, openPrs: 1, branch: 'master', source: 'github', complianceStatus: 'compliant' },
  { id: '4', name: 'mobile-app-react-native', description: 'Cross-platform customer loyalty app', language: 'TypeScript', stars: 210, openPrs: 5, branch: 'main', source: 'github', complianceStatus: 'pending' }
];

export default function App() {
  // --- State ---
  const [repos, setRepos] = useState<Repository[]>(INITIAL_REPOS);
  const [currentView, setCurrentView] = useState<'workspace' | 'chat'>('workspace');
  const [input, setInput] = useState('');
  const [selectedRepoId, setSelectedRepoId] = useState<string | null>('5'); 
  const [stage, setStage] = useState<WorkflowStage>(WorkflowStage.IDLE);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAddRepoOpen, setIsAddRepoOpen] = useState(false);
  const [hasError, setHasError] = useState(false);
  
  // Detail Modal State
  const [detailModal, setDetailModal] = useState<{ isOpen: boolean; type: 'story' | 'task' | 'code'; data: any }>({
    isOpen: false,
    type: 'story',
    data: null
  });

  // Artifacts
  const [stories, setStories] = useState<UserStory[]>([]);
  const [tasks, setTasks] = useState<DevTask[]>([]);
  const [codeFiles, setCodeFiles] = useState<CodeFile[]>([]);
  const [docFiles, setDocFiles] = useState<CodeFile[]>([]); 
  const [reviews, setReviews] = useState<CodeReviewComment[]>([]);
  const [buildLogs, setBuildLogs] = useState<string[]>([]);
  const [featureBranch, setFeatureBranch] = useState<string>('');
  const [summary, setSummary] = useState<string[]>([]);
  const [testCoverage, setTestCoverage] = useState<number>(0);
  const [codeGenProgress, setCodeGenProgress] = useState<number>(0);
  
  // Approval / Rework State
  const [changeRequestFeedback, setChangeRequestFeedback] = useState('');

  // Logs
  const [logs, setLogs] = useState<AgentLog[]>([]);
  
  // UI
  const [activeTab, setActiveTab] = useState('stories');

  // Derived State
  const selectedRepo = selectedRepoId ? repos.find(r => r.id === selectedRepoId) : null;

  // --- Dynamic Preview Generation ---
  const previewUrl = useMemo(() => {
    if (codeFiles.length === 0) return null;
    const indexFile = codeFiles.find(f => f.path.toLowerCase().includes('index.html'));
    let content = indexFile ? indexFile.content : `<html><body style="background:#0f172a;color:#fff;font-family:sans-serif;padding:2rem;"><h1>Live Preview</h1><p>Files: ${codeFiles.length}</p></body></html>`;
    const blob = new Blob([content], { type: 'text/html' });
    return URL.createObjectURL(blob);
  }, [codeFiles]);

  const addLog = useCallback((role: AgentRole, message: string, type: AgentLog['type'] = 'info') => {
    setLogs(prev => [...prev, {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
      role,
      message,
      type
    }]);
  }, []);

  const resetWorkflow = () => {
    setLogs([]);
    setStories([]);
    setTasks([]);
    setCodeFiles([]);
    setDocFiles([]);
    setReviews([]);
    setBuildLogs([]);
    setTestCoverage(0);
    setCodeGenProgress(0);
    setActiveTab('stories');
    setFeatureBranch('');
    setSummary([]);
    setChangeRequestFeedback('');
    setHasError(false);
  };

  const startWorkflow = () => {
    if (!input.trim() || stage !== WorkflowStage.IDLE) return;
    runRequirements();
  };

  const openDetail = (type: 'story' | 'task' | 'code', data: any) => {
    setDetailModal({ isOpen: true, type, data });
  };

  const runRequirements = async () => {
    setStage(WorkflowStage.REQUIREMENTS);
    setActiveTab('stories');
    try {
      addLog(AgentRole.BMAD_ORCHESTRATOR, "Drafting User Stories...");
      const generatedStories = await agentService.generateUserStories(input, selectedRepo || undefined, changeRequestFeedback, stories);
      setStories(generatedStories);
      setStage(WorkflowStage.APPROVE_REQUIREMENTS);
    } catch (e: any) { setStage(WorkflowStage.IDLE); }
  };

  const runPlanning = async () => {
    setStage(WorkflowStage.PLANNING);
    setActiveTab('tasks');
    try {
      addLog(AgentRole.BMAD_ORCHESTRATOR, "Synthesizing Dev Plan...");
      const generatedTasks = await agentService.generateDevTasks(stories, changeRequestFeedback);
      setTasks(generatedTasks);
      const branchName = `feature/copilot-f${Math.floor(Math.random() * 1000)}`;
      setFeatureBranch(branchName);
      addLog(AgentRole.COPILOT_WORKSPACE, `Initialized branch: ${branchName}`, 'success');
      setStage(WorkflowStage.APPROVE_PLANNING);
    } catch (e: any) { setHasError(true); }
  };

  const runCoding = async (forcePass: boolean = false) => {
    setStage(WorkflowStage.CODING);
    setActiveTab('code');
    setCodeGenProgress(0);
    try {
      addLog(AgentRole.COPILOT_CORE, "Implementing tasks...");
      setTasks(prev => prev.map(t => ({ ...t, status: 'IN_PROGRESS' })));
      
      const codePromise = agentService.generateCode(tasks, input, selectedRepo || undefined, changeRequestFeedback);
      const docsPromise = agentService.generateProjectDocs(stories, tasks);

      // Fast-fake progress for Code Generation specifically
      let progress = 0;
      const progressInterval = setInterval(() => {
        if (progress < 95) {
          progress += Math.random() * 10;
          setCodeGenProgress(Math.floor(progress));
        }
      }, 50);

      const [generatedFiles, generatedDocs] = await Promise.all([codePromise, docsPromise]);
      clearInterval(progressInterval);
      setCodeGenProgress(100);
      
      // Calculate coverage separately as a static stat
      const finalCoverage = forcePass ? 82 : (Math.random() > 0.15 ? 84 : 76);
      setTestCoverage(finalCoverage);
      
      setCodeFiles([...generatedFiles, ...COMPLIANCE_FILES]);
      setDocFiles(generatedDocs);
      setTasks(prev => prev.map(t => ({ ...t, status: 'CODE_REVIEW' })));
      
      setStage(WorkflowStage.REVIEW);
      setActiveTab('pr');
      const codeReviews = await agentService.reviewCode([...generatedFiles, ...COMPLIANCE_FILES]);
      setReviews(codeReviews);
      setStage(WorkflowStage.APPROVE_CODE);
    } catch (e: any) { setHasError(true); }
  };

  const runChecks = async () => {
    setStage(WorkflowStage.CHECKS);
    setActiveTab('build');
    try {
      addLog(AgentRole.GITHUB_ACTIONS, "Running CI checks on feature branch...");
      const steps = ["Setup", "Install", "Lint", "Test", "Security Scan", "Deploy Preview"];
      for (const step of steps) {
          setBuildLogs(prev => [...prev, `[${featureBranch}] Running ${step}...`]);
          await new Promise(r => setTimeout(r, 80));
      }
      setActiveTab('preview');
      setStage(WorkflowStage.APPROVE_PREVIEW);
    } catch (e: any) { setHasError(true); }
  };

  const runDeployment = async () => {
    setStage(WorkflowStage.MERGING);
    setActiveTab('pr');
    try {
      addLog(AgentRole.GITHUB_ACTIONS, `Merging ${featureBranch} into main...`);
      await new Promise(r => setTimeout(r, 500));
      
      setStage(WorkflowStage.DEPLOYING);
      setActiveTab('build');
      addLog(AgentRole.GITHUB_ACTIONS, "Promoting main to production...");
      setBuildLogs(prev => [...prev, "[main] PR Merged successfully.", "[main] Deploying to Production cluster..."]);
      await new Promise(r => setTimeout(r, 400));
      
      setStage(WorkflowStage.DONE);
      setSummary(["Workflow successful.", `Coverage: ${testCoverage}%`, "Merged to main."]);
      setActiveTab('done');
      addLog(AgentRole.BMAD_ORCHESTRATOR, "Project successfully deployed to production!", 'success');
    } catch (e: any) { setHasError(true); }
  };

  const handleApprove = () => {
    if (stage === WorkflowStage.APPROVE_REQUIREMENTS) runPlanning();
    else if (stage === WorkflowStage.APPROVE_PLANNING) runCoding();
    else if (stage === WorkflowStage.APPROVE_CODE) {
        if (testCoverage < 80) runCoding(true);
        else runChecks();
    }
    else if (stage === WorkflowStage.APPROVE_PREVIEW) runDeployment();
  };

  const handleOnboarding = async () => {
    if (!selectedRepo) return;
    setStage(WorkflowStage.ONBOARDING);
    setActiveTab('code');
    addLog(AgentRole.BMAD_ORCHESTRATOR, `Initializing BMAD framework for ${selectedRepo.name}...`);
    
    let progress = 0;
    const progressInterval = setInterval(() => {
       progress += 10;
       if (progress > 100) { setCodeGenProgress(100); clearInterval(progressInterval); }
       else setCodeGenProgress(progress);
    }, 40);

    const artifacts = await agentService.generateOnboardingArtifacts(selectedRepo);
    setCodeFiles(artifacts);
    setTestCoverage(80);
    setStage(WorkflowStage.APPROVE_CODE);
  };

  const handleRevert = () => {
    setHasError(false);
    setStage(WorkflowStage.IDLE);
  };

  const handleAddRepo = async (name: string, description: string, language: string) => {
      const newRepo: Repository = {
          id: Math.random().toString(36).substr(2, 9),
          name, description, language,
          stars: 0, openPrs: 0, branch: 'main', source: 'github', complianceStatus: 'missing'
      };
      setRepos(prev => [newRepo, ...prev]);
      setSelectedRepoId(newRepo.id);
      resetWorkflow();
      setStage(WorkflowStage.IDLE);
  };

  return (
    <div className="flex h-screen bg-[#010409] text-slate-200 font-sans">
      <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
      <AddRepoModal isOpen={isAddRepoOpen} onClose={() => setIsAddRepoOpen(false)} onAdd={handleAddRepo} />
      <DetailModal 
        isOpen={detailModal.isOpen} 
        onClose={() => setDetailModal(prev => ({ ...prev, isOpen: false }))} 
        type={detailModal.type} 
        data={detailModal.data} 
      />
      
      <Sidebar 
        repos={repos} 
        selectedRepoId={selectedRepoId} 
        onSelectRepo={(id) => { setSelectedRepoId(id); resetWorkflow(); setStage(WorkflowStage.IDLE); }} 
        onSettingsClick={() => setIsSettingsOpen(true)}
        currentView={currentView}
        onViewChange={setCurrentView}
        onAddRepoClick={() => setIsAddRepoOpen(true)}
      />

      <div className="flex-1 flex flex-col overflow-hidden relative">
        {currentView === 'chat' ? <CopilotChat /> : (
        <>
        <header className="h-14 border-b border-slate-800 bg-[#0d1117] flex items-center justify-between px-6">
          <div className="flex items-center gap-3">
            <h2 className="font-semibold text-sm text-slate-200">
              {selectedRepo ? `${selectedRepo.source} / ${selectedRepo.name}` : 'New Project'}
            </h2>
            {featureBranch && (
              <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-blue-900/20 border border-blue-500/30 text-[10px] text-blue-400 font-mono">
                <GitBranch size={10} /> {featureBranch}
              </div>
            )}
          </div>
          <div className="flex items-center gap-4 text-xs">
             <div className="flex items-center gap-2">
               <div className={`w-2 h-2 rounded-full ${stage === WorkflowStage.IDLE ? 'bg-green-500' : 'bg-yellow-500 animate-pulse'}`}></div>
               <span className="text-slate-400 capitalize">{stage.toLowerCase().replace('_', ' ')}</span>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-6xl mx-auto space-y-6">
            <section className="max-w-3xl mx-auto">
              {stage === WorkflowStage.IDLE && (
                 <>
                 {selectedRepo && selectedRepo.complianceStatus !== 'compliant' ? (
                   <div className="bg-[#0d1117] border border-slate-800 rounded-xl p-8 text-center shadow-2xl">
                      <ShieldCheck size={48} className="mx-auto mb-4 text-orange-500" />
                      <h1 className="text-2xl font-bold mb-2">Repository Not Onboarded</h1>
                      <p className="text-slate-400 mb-6 text-sm">This repository is missing the BMAD configuration files and required CI/CD workflows.</p>
                      <button onClick={handleOnboarding} className="px-8 py-3 bg-orange-600 hover:bg-orange-500 text-white rounded-lg font-bold flex items-center gap-2 mx-auto transition-all shadow-lg shadow-orange-900/20">
                         <Wrench size={18} /> Initialize BMAD Onboarding
                      </button>
                   </div>
                 ) : (
                    <div className="text-center mb-8">
                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-900/20 border border-blue-500/30 text-blue-400 text-[10px] font-bold uppercase tracking-widest mb-4">
                           <Sparkles size={12} /> Agentic Workspace
                        </div>
                        <h1 className="text-3xl font-extrabold text-white mb-2">Build your vision.</h1>
                        <p className="text-slate-500 text-sm">Powered by BMAD Framework & Gemini Pro</p>
                    </div>
                 )}
                 </>
              )}
              
              {stage === WorkflowStage.IDLE && (!selectedRepo || selectedRepo.complianceStatus === 'compliant') && (
                  <div className="relative group">
                    <div className="bg-[#0d1117] rounded-xl p-1.5 flex items-center shadow-2xl border border-slate-700 group-focus-within:border-blue-500 transition-all">
                      <div className="pl-4 pr-2 text-slate-500"><Brain size={20} /></div>
                      <input 
                        value={input} onChange={(e) => setInput(e.target.value)}
                        placeholder="What should we build today?" 
                        className="w-full bg-transparent border-none px-2 py-3 text-lg focus:outline-none text-white"
                        onKeyDown={(e) => e.key === 'Enter' && startWorkflow()}
                      />
                      <button onClick={startWorkflow} className="px-6 py-2.5 m-1 bg-white hover:bg-slate-200 text-black rounded-lg font-bold transition-all flex items-center gap-2">
                        <ArrowRight size={18} />
                      </button>
                    </div>
                  </div>
              )}
              {stage === WorkflowStage.IDLE && <div className="mt-12"><DashboardStats /></div>}
            </section>

            {stage !== WorkflowStage.IDLE && (
              <section className="grid grid-cols-5 gap-3">
                {[AgentRole.COPILOT_WORKSPACE, AgentRole.BMAD_ORCHESTRATOR, AgentRole.COPILOT_CORE, AgentRole.GITHUB_ACTIONS, AgentRole.COPILOT_SECURITY].map(role => (
                   <AgentCard 
                      key={role} 
                      role={role} 
                      isActive={stage !== WorkflowStage.DONE && (
                        (role === AgentRole.BMAD_ORCHESTRATOR && (stage.includes('REQUIREMENTS') || stage.includes('PLANNING'))) ||
                        (role === AgentRole.COPILOT_CORE && stage.includes('CODING')) ||
                        (role === AgentRole.GITHUB_ACTIONS && (stage.includes('CHECKS') || stage.includes('MERGING') || stage.includes('DEPLOYING'))) ||
                        (role === AgentRole.COPILOT_SECURITY && stage.includes('REVIEW'))
                      )} 
                      statusMessage="..." 
                   />
                ))}
              </section>
            )}

            {stage !== WorkflowStage.IDLE && (
              <section className="space-y-4">
                <WorkflowSteps currentStage={stage} />
                <div className="grid grid-cols-12 gap-6">
                  <div className="col-span-4 flex flex-col gap-6">
                    <LogTerminal logs={logs} />
                    <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-4 flex items-center justify-between">
                       <div className="flex items-center gap-3">
                          <div className="p-2 bg-blue-900/30 text-blue-400 rounded-lg"><Clock size={16} /></div>
                          <div>
                             <div className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Est. Completion</div>
                             <div className="text-sm font-bold text-slate-200">~2 minutes</div>
                          </div>
                       </div>
                       <Activity size={16} className="text-slate-700" />
                    </div>
                  </div>
                  <div className="col-span-8 bg-[#0d1117] border border-slate-800 rounded-xl flex flex-col min-h-[600px] shadow-2xl">
                    <div className="p-2 border-b border-slate-800 bg-[#161b22]/50">
                      <Tabs activeTab={activeTab} onTabChange={setActiveTab}
                        tabs={[{id:'stories',label:'Spec'},{id:'tasks',label:'Plan'},{id:'code',label:'Code'},{id:'pr',label:'PR'},{id:'build',label:'CI/CD'},{id:'preview',label:'Preview'}]} 
                      />
                    </div>
                    <div className="flex-1 p-6 bg-[#010409] overflow-y-auto custom-scrollbar">
                      
                      {activeTab === 'stories' && (
                        <div className="space-y-4">
                           <div className="flex items-center justify-between mb-4">
                              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest">Product Specifications</h3>
                              <span className="px-2 py-0.5 rounded bg-blue-900/20 text-blue-400 text-[10px]">{stories.length} Stories</span>
                           </div>
                           {stories.length === 0 ? <div className="text-slate-600 italic">Generating specs...</div> : stories.map(s => (
                             <div 
                                key={s.id} 
                                onClick={() => openDetail('story', s)}
                                className="p-4 bg-[#0d1117] rounded-lg border border-slate-800 hover:border-blue-500/50 hover:bg-[#161b22] transition-all cursor-pointer group relative overflow-hidden"
                             >
                                <div className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-700 group-hover:text-blue-400 transition-colors opacity-0 group-hover:opacity-100">
                                   <ChevronRight size={20} />
                                </div>
                                <h4 className="font-bold text-slate-200 flex items-center gap-2 mb-2 pr-8">
                                   <FileText size={16} className="text-blue-400" /> {s.title}
                                </h4>
                                <p className="text-xs text-slate-400 leading-relaxed truncate pr-8">{s.description}</p>
                             </div>
                           ))}
                        </div>
                      )}

                      {activeTab === 'tasks' && (
                        <div className="space-y-4">
                           <div className="flex items-center justify-between mb-4">
                              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest">Development Plan (JIRA)</h3>
                              <span className="px-2 py-0.5 rounded bg-purple-900/20 text-purple-400 text-[10px]">{tasks.length} Issues</span>
                           </div>
                           {tasks.length === 0 ? <div className="text-slate-600 italic">Synthesizing plan...</div> : tasks.map(t => (
                             <div 
                                key={t.id} 
                                onClick={() => openDetail('task', t)}
                                className="p-3 bg-[#0d1117] rounded-lg border border-slate-800 flex items-center justify-between group cursor-pointer hover:border-purple-500/50 hover:bg-[#161b22] transition-all"
                             >
                                <div className="flex items-center gap-4">
                                   <div className="text-[10px] font-bold text-slate-500 font-mono w-16 uppercase">SAP-{t.id.slice(0,3)}</div>
                                   <div className="text-sm font-medium text-slate-300 group-hover:text-white transition-colors">{t.title}</div>
                                </div>
                                <div className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                   t.status === 'DONE' ? 'bg-green-900/20 text-green-400' :
                                   t.status === 'IN_PROGRESS' ? 'bg-blue-900/20 text-blue-400' :
                                   'bg-slate-800 text-slate-400'
                                }`}>{t.status}</div>
                             </div>
                           ))}
                        </div>
                      )}

                      {activeTab === 'code' && (
                        <div className="space-y-4">
                           {(stage === WorkflowStage.CODING || stage === WorkflowStage.ONBOARDING) && (
                             <div className="bg-[#161b22] p-4 rounded-xl border border-slate-700 mb-6 shadow-lg">
                                <div className="flex justify-between items-center mb-2">
                                   <div className="flex items-center gap-2">
                                      <RefreshCw size={14} className="text-blue-400 animate-spin" />
                                      <span className="text-xs font-bold text-blue-400 uppercase tracking-widest">Code Synthesis In Progress</span>
                                   </div>
                                   <span className="text-xs font-mono text-slate-500">{codeGenProgress}%</span>
                                </div>
                                <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                                   <div className="h-full bg-blue-500 transition-all duration-300 ease-out" style={{width: `${codeGenProgress}%`}}></div>
                                </div>
                             </div>
                           )}

                           <div className="flex items-center justify-between mb-2">
                              <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest">Generated Files</h3>
                              <span className="text-[10px] text-slate-500">{codeFiles.length} Artifacts</span>
                           </div>

                           <div className="grid grid-cols-2 gap-4">
                              {codeFiles.map(f => (
                                 <div 
                                    key={f.path} 
                                    onClick={() => openDetail('code', f)}
                                    className="p-3 bg-[#0d1117] border border-slate-800 rounded-lg flex items-center gap-3 hover:border-slate-500 hover:bg-[#161b22] transition-all cursor-pointer group"
                                 >
                                    <div className="p-2 bg-slate-800 rounded text-blue-400 group-hover:bg-blue-900/30 transition-colors"><FileCode size={16} /></div>
                                    <div className="flex-1 min-w-0">
                                       <div className="text-[11px] font-bold text-slate-300 truncate group-hover:text-white">{f.path}</div>
                                       <div className="text-[9px] text-slate-500 uppercase tracking-widest">{f.language}</div>
                                    </div>
                                    <div className="text-green-500/50 group-hover:text-green-400"><CheckIcon size={12} /></div>
                                 </div>
                              ))}
                           </div>
                        </div>
                      )}

                      {activeTab === 'pr' && (
                        <div className="space-y-6">
                           {/* PR Header Widget */}
                           <div className="bg-[#161b22] border border-slate-700 rounded-xl overflow-hidden shadow-2xl">
                              <div className="p-4 bg-slate-800/50 flex items-center justify-between border-b border-slate-700">
                                 <div className="flex items-center gap-3">
                                    <div className="p-2 bg-purple-900/30 text-purple-400 rounded-lg"><GitPullRequest size={20} /></div>
                                    <div>
                                       <h3 className="font-bold text-white text-sm">Implementation: {input.slice(0, 40)}...</h3>
                                       <div className="flex items-center gap-2 mt-1">
                                          <span className="px-1.5 py-0.5 rounded bg-blue-900/20 text-blue-400 text-[10px] font-mono">{featureBranch || 'feature-branch'}</span>
                                          <ArrowRight size={10} className="text-slate-600" />
                                          <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 text-[10px] font-mono">main</span>
                                       </div>
                                    </div>
                                 </div>
                                 <div className={`px-3 py-1 rounded-full border text-xs font-bold ${stage === WorkflowStage.DONE ? 'bg-green-900/20 text-green-400 border-green-500/30' : 'bg-blue-900/20 text-blue-400 border-blue-500/30'}`}>
                                    {stage === WorkflowStage.DONE ? 'MERGED' : 'OPEN'}
                                 </div>
                              </div>
                              
                              {/* Statistics Section */}
                              <div className="grid grid-cols-3 border-b border-slate-700 bg-slate-900/40">
                                 <div className="p-4 border-r border-slate-700 flex flex-col items-center text-center">
                                    <span className="text-[9px] text-slate-500 uppercase font-bold tracking-widest mb-1">Code Coverage</span>
                                    <div className={`text-lg font-bold ${testCoverage >= 80 ? 'text-green-400' : 'text-red-400'}`}>
                                       {testCoverage > 0 ? `${testCoverage}%` : '--'}
                                    </div>
                                    <span className="text-[8px] text-slate-600 font-bold uppercase">Req: 80%</span>
                                 </div>
                                 <div className="p-4 border-r border-slate-700 flex flex-col items-center text-center">
                                    <span className="text-[9px] text-slate-500 uppercase font-bold tracking-widest mb-1">Security Score</span>
                                    <div className="text-lg font-bold text-white">A+</div>
                                    <span className="text-[8px] text-slate-600 font-bold uppercase">CodeQL Passed</span>
                                 </div>
                                 <div className="p-4 flex flex-col items-center text-center">
                                    <span className="text-[9px] text-slate-500 uppercase font-bold tracking-widest mb-1">Files Changed</span>
                                    <div className="text-lg font-bold text-white">{codeFiles.length}</div>
                                    <span className="text-[8px] text-slate-600 font-bold uppercase">Automated</span>
                                 </div>
                              </div>

                              <div className="p-4 bg-[#0d1117]">
                                 <div className="flex items-center gap-2 mb-4 justify-between">
                                    <div className="flex items-center gap-2">
                                       <div className="flex -space-x-2">
                                          <div className="w-6 h-6 rounded-full bg-slate-700 border border-slate-950 flex items-center justify-center text-[10px]">AI</div>
                                          <div className="w-6 h-6 rounded-full bg-blue-600 border border-slate-950 flex items-center justify-center text-[10px]">US</div>
                                       </div>
                                       <span className="text-[10px] text-slate-500">2 reviewers • High Quality</span>
                                    </div>
                                    <div className="flex items-center gap-1 text-[10px] font-bold text-green-500">
                                       <ShieldCheck size={12} /> SOC2 Compliant
                                    </div>
                                 </div>
                                 <div className="space-y-3">
                                    {reviews.length === 0 ? <div className="text-[10px] text-slate-600 italic">Performing code audit...</div> : reviews.map((r, i) => (
                                       <div key={i} className={`p-3 rounded-lg flex items-start gap-3 border ${
                                          r.severity === 'HIGH' ? 'bg-red-900/10 border-red-900/30' : 'bg-slate-900 border-slate-800'
                                       }`}>
                                          <AlertOctagon size={16} className={`${r.severity === 'HIGH' ? 'text-red-500' : 'text-slate-500'} mt-0.5 shrink-0`} />
                                          <div>
                                             <div className={`text-[10px] font-bold uppercase tracking-widest mb-1 ${r.severity === 'HIGH' ? 'text-red-400' : 'text-slate-400'}`}>
                                                {r.severity} Severity Comment
                                             </div>
                                             <div className="text-[11px] text-slate-300">{r.comment}</div>
                                          </div>
                                       </div>
                                    ))}
                                    {stage === WorkflowStage.DONE && (
                                       <div className="p-3 bg-green-900/10 border border-green-900/30 rounded flex items-start gap-3">
                                          <CheckIcon size={16} className="text-green-500 mt-0.5 shrink-0" />
                                          <div>
                                             <div className="text-[10px] font-bold text-green-400 uppercase tracking-tighter mb-1">PR MERGED</div>
                                             <div className="text-[11px] text-slate-300">Code successfully verified and merged to production branch.</div>
                                          </div>
                                       </div>
                                    )}
                                 </div>
                              </div>
                           </div>
                        </div>
                      )}

                      {activeTab === 'build' && (
                        <div className="space-y-4 font-mono text-xs">
                           <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-2">
                              <span className="text-slate-500 uppercase tracking-widest font-sans font-bold">CI/CD Pipeline Logs</span>
                              <div className="flex items-center gap-2">
                                 <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                                 <span className="text-green-400 font-sans font-bold uppercase tracking-widest">Active Runner</span>
                              </div>
                           </div>
                           <div className="bg-[#010409] p-4 rounded-lg border border-slate-800 space-y-1 shadow-inner">
                              {buildLogs.map((log, i) => (
                                 <div key={i} className="flex gap-4">
                                    <span className="text-slate-700 w-4 select-none">{i+1}</span>
                                    <span className="text-slate-400">{log}</span>
                                 </div>
                              ))}
                              {stage !== WorkflowStage.DONE && <div className="text-blue-500 animate-pulse ml-8 mt-2">▋</div>}
                           </div>
                        </div>
                      )}

                      {activeTab === 'preview' && (
                        <div className="h-full flex flex-col">
                           <div className="bg-[#161b22] p-2 border border-slate-700 rounded-t-lg flex items-center gap-2">
                              <div className="flex gap-1.5 ml-1">
                                 <div className="w-2.5 h-2.5 rounded-full bg-red-500/50"></div>
                                 <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/50"></div>
                                 <div className="w-2.5 h-2.5 rounded-full bg-green-500/50"></div>
                              </div>
                              <div className="flex-1 bg-slate-900 px-3 py-1 rounded text-[10px] text-slate-400 font-mono text-center truncate border border-slate-800">
                                 https://{featureBranch || 'preview'}.bmad-studio.dev
                              </div>
                           </div>
                           {previewUrl ? (
                              <iframe src={previewUrl} className="flex-1 w-full bg-white rounded-b-lg shadow-2xl" />
                           ) : (
                              <div className="flex-1 flex items-center justify-center bg-slate-900/50 rounded-b-lg border border-t-0 border-slate-700">
                                 <div className="text-center">
                                    <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center text-slate-600 mx-auto mb-4 border border-slate-700">
                                       <PlayCircle size={32} />
                                    </div>
                                    <p className="text-slate-500 text-sm">Waiting for CI to deploy feature preview...</p>
                                 </div>
                              </div>
                           )}
                        </div>
                      )}

                      {activeTab === 'done' && (
                        <div className="flex flex-col items-center justify-center py-20 animate-in zoom-in-95 duration-500">
                           <div className="w-24 h-24 rounded-full bg-green-500/10 border-4 border-green-500 flex items-center justify-center text-green-500 mb-8 shadow-2xl shadow-green-500/20">
                              <CheckCircle2 size={48} className="animate-in zoom-in-50 duration-700" />
                           </div>
                           <h2 className="text-3xl font-extrabold text-white mb-2">Workflow Complete</h2>
                           <p className="text-slate-400 text-center max-w-md mb-10 leading-relaxed">
                              Successfully synthesized feature requirements, generated code, passed security audits, and merged <span className="text-blue-400 font-mono font-bold">{featureBranch}</span> into <span className="text-green-400 font-mono font-bold">main</span>.
                           </p>
                           <div className="flex gap-4">
                              <button onClick={() => { setStage(WorkflowStage.IDLE); resetWorkflow(); }} className="px-8 py-3 bg-white text-black font-bold rounded-xl hover:bg-slate-200 transition-all shadow-lg hover:scale-105">Start New Feature</button>
                              <button className="px-8 py-3 bg-slate-800 text-white font-bold rounded-xl hover:bg-slate-700 transition-all flex items-center gap-2 border border-slate-700">
                                 <ExternalLink size={18} /> Production Site
                              </button>
                           </div>
                        </div>
                      )}

                    </div>
                  </div>
                </div>
              </section>
            )}
          </div>
        </main>
        </>
        )}

        {stage.toString().startsWith('APPROVE') && currentView === 'workspace' && (
            <div className="fixed bottom-6 left-1/2 -translate-x-1/2 w-full max-w-2xl px-4 animate-in slide-in-from-bottom-5 duration-300">
              <div className="bg-[#161b22]/95 border border-slate-600 p-5 rounded-2xl shadow-2xl flex items-center justify-between backdrop-blur-md">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white shadow-lg shadow-blue-900/20">
                     <Brain size={20} />
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-sm uppercase tracking-widest">Awaiting Approval</h3>
                    <p className="text-[11px] text-slate-400">Review generated {stage.replace('APPROVE_','').toLowerCase()} items before continuing.</p>
                  </div>
                </div>
                <div className="flex gap-3">
                   <button onClick={() => setStage(WorkflowStage.IDLE)} className="px-4 py-2 text-xs text-red-400 font-bold hover:bg-red-900/20 rounded-lg transition-all">Discard</button>
                   <button onClick={handleApprove} className="px-8 py-2.5 bg-white text-black rounded-xl font-black text-xs hover:scale-105 active:scale-95 transition-all shadow-xl">Approve & Continue</button>
                </div>
              </div>
            </div>
        )}

        {hasError && <div className="absolute top-20 right-8 p-4 bg-red-950 border border-red-500 rounded-lg shadow-2xl animate-in fade-in duration-300"><button onClick={handleRevert} className="flex items-center gap-2 font-bold"><RotateCcw size={16} /> Reset System</button></div>}
      </div>
    </div>
  );
}
