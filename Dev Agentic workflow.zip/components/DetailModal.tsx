
import React from 'react';
import { X, FileText, Trello, FileCode, CheckCircle2, User, Hash, Clock, ShieldCheck, Copy } from 'lucide-react';
import { UserStory, DevTask, CodeFile } from '../types';

interface DetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'story' | 'task' | 'code';
  data: any;
}

const DetailModal: React.FC<DetailModalProps> = ({ isOpen, onClose, type, data }) => {
  if (!isOpen || !data) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[110] flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-[#0d1117] border border-slate-800 rounded-2xl w-full max-w-3xl shadow-2xl flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between p-6 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${
              type === 'story' ? 'bg-blue-900/30 text-blue-400' :
              type === 'task' ? 'bg-purple-900/30 text-purple-400' :
              'bg-slate-800 text-slate-300'
            }`}>
              {type === 'story' ? <FileText size={20} /> :
               type === 'task' ? <Trello size={20} /> : <FileCode size={20} />}
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">
                {type === 'story' ? (data as UserStory).title :
                 type === 'task' ? (data as DevTask).title : (data as CodeFile).path}
              </h2>
              <p className="text-xs text-slate-500 uppercase tracking-widest font-bold">
                {type} details
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-2 hover:bg-slate-800 rounded-full transition-colors">
            <X size={24} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
          {type === 'story' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-xs font-bold text-slate-500 uppercase mb-2">Description</h3>
                <p className="text-slate-300 leading-relaxed">{(data as UserStory).description}</p>
              </div>
              <div>
                <h3 className="text-xs font-bold text-slate-500 uppercase mb-3">Acceptance Criteria</h3>
                <div className="space-y-3">
                  {(data as UserStory).acceptanceCriteria.map((ac, i) => (
                    <div key={i} className="flex gap-3 p-3 bg-slate-900/50 rounded-lg border border-slate-800">
                      <div className="mt-0.5 text-blue-500"><CheckCircle2 size={16} /></div>
                      <span className="text-sm text-slate-400">{ac}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {type === 'task' && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-slate-900/50 rounded-xl border border-slate-800">
                  <div className="text-xs text-slate-500 font-bold uppercase mb-1 flex items-center gap-1">
                    <Hash size={12} /> Task ID
                  </div>
                  <div className="text-sm font-mono text-white">SAP-{(data as DevTask).id.slice(0, 6)}</div>
                </div>
                <div className="p-4 bg-slate-900/50 rounded-xl border border-slate-800">
                  <div className="text-xs text-slate-500 font-bold uppercase mb-1 flex items-center gap-1">
                    <User size={12} /> Assignee
                  </div>
                  <div className="text-sm text-white">{(data as DevTask).assignee}</div>
                </div>
              </div>
              <div>
                <h3 className="text-xs font-bold text-slate-500 uppercase mb-2">Technical Implementation</h3>
                <p className="text-slate-300 leading-relaxed">{(data as DevTask).description}</p>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-500">Linked Story:</span>
                <span className="text-blue-400 font-bold">#{(data as DevTask).linkedStoryId}</span>
              </div>
            </div>
          )}

          {type === 'code' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between p-2 bg-slate-900 rounded-lg border border-slate-800">
                <div className="flex items-center gap-2 text-xs px-2">
                  <span className="text-slate-500 uppercase tracking-widest font-bold">Language:</span>
                  <span className="text-blue-400 font-mono">{(data as CodeFile).language}</span>
                </div>
                <button className="p-1.5 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors">
                  <Copy size={14} />
                </button>
              </div>
              <div className="bg-[#010409] border border-slate-800 rounded-lg p-4 overflow-x-auto font-mono text-xs leading-relaxed text-slate-300 min-h-[300px]">
                <pre><code>{(data as CodeFile).content}</code></pre>
              </div>
            </div>
          )}
        </div>

        <div className="p-6 border-t border-slate-800 flex justify-end">
          <button onClick={onClose} className="px-6 py-2 bg-white text-slate-900 font-bold rounded-lg hover:bg-slate-200 transition-colors">
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default DetailModal;
