import { GoogleGenAI, Type, Chat } from "@google/genai";
import { UserStory, DevTask, CodeFile, CodeReviewComment, AgentRole, Repository } from "../types";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API_KEY is missing");
  return new GoogleGenAI({ apiKey });
};

// Schema Definitions
const userStorySchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      id: { type: Type.STRING },
      title: { type: Type.STRING },
      description: { type: Type.STRING },
      acceptanceCriteria: {
        type: Type.ARRAY,
        items: { type: Type.STRING }
      }
    },
    required: ["id", "title", "description", "acceptanceCriteria"]
  }
};

const devTaskSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      id: { type: Type.STRING },
      key: { type: Type.STRING },
      title: { type: Type.STRING },
      description: { type: Type.STRING },
      linkedStoryId: { type: Type.STRING },
      assignee: { type: Type.STRING } 
    },
    required: ["id", "key", "title", "description", "linkedStoryId", "assignee"]
  }
};

const codeFileSchema = {
  type: Type.OBJECT,
  properties: {
    files: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          path: { type: Type.STRING },
          content: { type: Type.STRING },
          language: { type: Type.STRING }
        },
        required: ["path", "content", "language"]
      }
    }
  }
};

const reviewSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      file: { type: Type.STRING },
      severity: { type: Type.STRING },
      comment: { type: Type.STRING },
      suggestion: { type: Type.STRING }
    },
    required: ["file", "severity", "comment"]
  }
};

export const agentService = {
  // Use gemini-3-pro-preview for complex architectural and chat tasks
  createChat(): Chat {
    const ai = getClient();
    return ai.chats.create({
      model: 'gemini-3-pro-preview',
      config: {
        systemInstruction: "You are a fast, expert AI software development assistant. Provide concise, direct answers and production-ready artifacts for the BMAD framework.",
      }
    });
  },

  async generateUserStories(input: string, repo?: Repository, feedback?: string, existingStories?: UserStory[]): Promise<UserStory[]> {
    const ai = getClient();
    const context = repo 
      ? `Repo: "${repo.name}". Desc: "${repo.description}". Request: "${input}".`
      : `Request: "${input}".`;

    let prompt = `Task: Generate professional User Stories. Context: ${context}`;

    if (feedback && existingStories && existingStories.length > 0) {
      prompt = `Refine these stories based on feedback: "${feedback}". Current: ${JSON.stringify(existingStories)}`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: userStorySchema,
      }
    });
    
    if (response.text) return JSON.parse(response.text) as UserStory[];
    throw new Error("Failed to generate stories");
  },

  async generateDevTasks(stories: UserStory[], feedback?: string): Promise<DevTask[]> {
    const ai = getClient();
    let prompt = `Convert stories to technical tasks. stories: ${JSON.stringify(stories)}`;
    if (feedback) prompt += `. Adjust for: ${feedback}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: devTaskSchema,
      }
    });

    if (response.text) {
      const rawTasks = JSON.parse(response.text) as any[];
      return rawTasks.map(t => ({ ...t, assignee: AgentRole.COPILOT_CORE, status: 'TODO' }));
    }
    throw new Error("Failed to plan tasks");
  },

  async generateCode(tasks: DevTask[], projectContext: string, repo?: Repository, feedback?: string): Promise<CodeFile[]> {
    const ai = getClient();
    const prompt = `Task: Code implementation for tasks: ${JSON.stringify(tasks)}. Request: ${projectContext}. Feedback: ${feedback || 'none'}. MANDATORY: High test coverage (80%+). Clean files.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview', 
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: codeFileSchema,
      }
    });

    if (response.text) return (JSON.parse(response.text)).files as CodeFile[];
    throw new Error("Failed to generate code");
  },

  async generateOnboardingArtifacts(repo: Repository): Promise<CodeFile[]> {
    const ai = getClient();
    const prompt = `Onboard repo "${repo.name}" to BMAD. Generate bmad.config.json, CI/CD, SECURITY.md, and mock source+test files for 80% coverage.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: codeFileSchema,
      }
    });

    if (response.text) return (JSON.parse(response.text)).files as CodeFile[];
    throw new Error("Onboarding failed");
  },

  async generateProjectDocs(stories: UserStory[], tasks: DevTask[]): Promise<CodeFile[]> {
    const ai = getClient();
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Docs for: ${JSON.stringify(stories)}. Generate TECHNICAL_ARCHITECTURE.md, USER_GUIDE.md, TEST_PLAN.md.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: codeFileSchema,
      }
    });

    if (response.text) return (JSON.parse(response.text)).files as CodeFile[];
    return [];
  },

  async reviewCode(files: CodeFile[]): Promise<CodeReviewComment[]> {
    const ai = getClient();
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Audit these files for security/quality: ${JSON.stringify(files.map(f => ({path: f.path})))}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: reviewSchema,
      }
    });

    if (response.text) return JSON.parse(response.text) as CodeReviewComment[];
    throw new Error("Security audit failed");
  }
};